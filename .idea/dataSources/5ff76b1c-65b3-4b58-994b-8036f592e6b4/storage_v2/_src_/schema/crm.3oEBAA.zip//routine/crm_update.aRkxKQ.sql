create
    definer = vevor@`%` procedure crm_update()
BEGIN

-- 服务版本：1.2.2 
-- 修改crm_sku的唯一索引
drop index `unique_platform_website_sku_platcode` on `crm_sku` ;
create unique index unique_sku on `crm_sku` (`ref_platform_id`, `ref_website_id`, `product_sku`, `product_plateform_code`, `top_seller`, `system_sku`) ;

-- 储存过程crm_update结束
END;

