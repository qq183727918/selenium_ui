create definer = vevor@`%` trigger attr_int_after_update
    after update
    on goods_attr_int
    for each row
BEGIN 
IF NEW.attr_id=3 THEN 
UPDATE `view_goods_sku_basic_info` SET `spu_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=7 THEN 
UPDATE `view_goods_sku_basic_info` SET `developer_group`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=8 THEN 
UPDATE `view_goods_sku_basic_info` SET `current_status_number`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=10 THEN 
UPDATE `view_goods_sku_basic_info` SET `developer`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=12 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_reject`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=15 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_time_out`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=18 THEN 
UPDATE `view_goods_sku_basic_info` SET `deferred_days`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=19 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_invalid`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=22 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_delete`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=27 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_informal`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=28 THEN 
UPDATE `view_goods_sku_basic_info` SET `category_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=30 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_second_sale`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=34 THEN 
UPDATE `view_goods_sku_basic_info` SET `buyer_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=35 THEN 
UPDATE `view_goods_sku_basic_info` SET `user_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=37 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_sold_separate`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=38 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_purchase_sample`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=40 THEN 
UPDATE `view_goods_sku_basic_info` SET `erp_develop_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=41 THEN 
UPDATE `view_goods_sku_basic_info` SET `erp_goods_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=58 THEN 
UPDATE `view_goods_package_info` SET `package_texture`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=59 THEN 
UPDATE `view_goods_package_info` SET `is_cylinder`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=60 THEN 
UPDATE `view_goods_package_info` SET `is_package_merger`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=61 THEN 
UPDATE `view_goods_package_info` SET `is_split_package`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=66 THEN 
UPDATE `view_goods_package_info` SET `is_delete`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=82 THEN 
UPDATE `view_goods_information_basic_info` SET `plug`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=87 THEN 
UPDATE `view_goods_information_basic_info` SET `classification_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=91 THEN 
UPDATE `view_goods_information_basic_info` SET `is_unpacking`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=94 THEN 
UPDATE `view_goods_information_basic_info` SET `is_sold_separately`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=95 THEN 
UPDATE `view_goods_information_basic_info` SET `category`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=96 THEN 
UPDATE `view_goods_information_basic_info` SET `unit`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=97 THEN 
UPDATE `view_goods_information_basic_info` SET `packaging_material`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=98 THEN 
UPDATE `view_goods_information_basic_info` SET `is_second_sale`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=106 THEN 
UPDATE `view_goods_information_basic_info` SET `is_fumigation`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=107 THEN 
UPDATE `view_goods_information_basic_info` SET `is_epa`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=108 THEN 
UPDATE `view_goods_information_basic_info` SET `is_fda`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=113 THEN 
UPDATE `view_goods_information_basic_info` SET `developer_group`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=114 THEN 
UPDATE `view_goods_information_basic_info` SET `developer`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=115 THEN 
UPDATE `view_goods_information_basic_info` SET `is_danger`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=122 THEN 
UPDATE `view_goods_information_basic_info` SET `is_delete`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=136 THEN 
UPDATE `view_goods_information_size_info` SET `is_delete`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=137 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_show_in_information`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=138 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_brand`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=141 THEN 
UPDATE `view_goods_sku_basic_info` SET `voltage_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=142 THEN 
UPDATE `view_goods_sku_basic_info` SET `plug_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=144 THEN 
UPDATE `view_goods_sku_basic_info` SET `main_sku_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=147 THEN 
UPDATE `view_goods_sku_basic_info` SET `is_tax_refund`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
END;

