create definer = vevor@`%` trigger attr_decimal_after_update
    after update
    on goods_attr_decimal
    for each row
BEGIN 
IF NEW.attr_id=39 THEN 
UPDATE `view_goods_sku_basic_info` SET `version`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=44 THEN 
UPDATE `view_goods_package_info` SET `package_length`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=45 THEN 
UPDATE `view_goods_package_info` SET `package_wide`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=46 THEN 
UPDATE `view_goods_package_info` SET `package_high`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=47 THEN 
UPDATE `view_goods_package_info` SET `package_weight`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=48 THEN 
UPDATE `view_goods_package_info` SET `bubble_weight_lb`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=49 THEN 
UPDATE `view_goods_package_info` SET `bubble_weight_kg`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=50 THEN 
UPDATE `view_goods_package_info` SET `item_length`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=51 THEN 
UPDATE `view_goods_package_info` SET `item_wide`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=52 THEN 
UPDATE `view_goods_package_info` SET `item_high`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=53 THEN 
UPDATE `view_goods_package_info` SET `full_weight`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=54 THEN 
UPDATE `view_goods_package_info` SET `package_volume`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=55 THEN 
UPDATE `view_goods_package_info` SET `perimeter_cm`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=56 THEN 
UPDATE `view_goods_package_info` SET `perimeter_inch`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=57 THEN 
UPDATE `view_goods_package_info` SET `charged_weight`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=124 THEN 
UPDATE `view_goods_information_size_info` SET `length_cm`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=125 THEN 
UPDATE `view_goods_information_size_info` SET `width_cm`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=126 THEN 
UPDATE `view_goods_information_size_info` SET `height_cm`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=127 THEN 
UPDATE `view_goods_information_size_info` SET `weight_kg`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=128 THEN 
UPDATE `view_goods_information_size_info` SET `length_inch`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=129 THEN 
UPDATE `view_goods_information_size_info` SET `width_inch`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=130 THEN 
UPDATE `view_goods_information_size_info` SET `height_inch`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=131 THEN 
UPDATE `view_goods_information_size_info` SET `weight_lbs`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=143 THEN 
UPDATE `view_goods_information_basic_info` SET `declared_value`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=148 THEN 
UPDATE `view_goods_sku_basic_info` SET `purchase_price_including_tax`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
END;

