create definer = vevor@`%` trigger attr_datetime_after_update
    after update
    on goods_attr_datetime
    for each row
BEGIN 
IF NEW.attr_id=16 THEN 
UPDATE `view_goods_sku_basic_info` SET `time_out_deadline_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=17 THEN 
UPDATE `view_goods_sku_basic_info` SET `audit_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=25 THEN 
UPDATE `view_goods_sku_basic_info` SET `updated_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=26 THEN 
UPDATE `view_goods_sku_basic_info` SET `create_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=62 THEN 
UPDATE `view_goods_package_info` SET `created_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=63 THEN 
UPDATE `view_goods_package_info` SET `updated_time`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
END;

