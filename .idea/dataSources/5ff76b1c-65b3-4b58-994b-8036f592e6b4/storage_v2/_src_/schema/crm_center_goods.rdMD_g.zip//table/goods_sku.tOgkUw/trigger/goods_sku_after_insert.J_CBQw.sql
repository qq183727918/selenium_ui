create definer = vevor@`%` trigger goods_sku_after_insert
    after insert
    on goods_sku
    for each row
BEGIN
-- 初始化五个表里面的属性值
INSERT INTO goods_attr_varchar ( `attr_id`, `goods_id`, `attr_value` ) SELECT
a.`id`,
b.`id`,
'' 
FROM
	goods_attr a
	INNER JOIN goods_sku b ON 1 = 1 
WHERE
	a.type = 0 
	AND b.`id` = NEW.`id`;
INSERT INTO goods_attr_decimal ( `attr_id`, `goods_id`, `attr_value` ) SELECT
a.`id`,
b.`id`,
null
FROM
	goods_attr a
	INNER JOIN goods_sku b ON 1 = 1 
WHERE
	a.type = 1 
	AND b.`id` = NEW.`id`;
INSERT INTO goods_attr_int ( `attr_id`, `goods_id`, `attr_value` ) SELECT
a.`id`,
b.`id`,
null
FROM
	goods_attr a
	INNER JOIN goods_sku b ON 1 = 1 
WHERE
	a.type = 2 
	AND b.`id` = NEW.`id`;
INSERT INTO goods_attr_datetime ( `attr_id`, `goods_id`, `attr_value` ) SELECT
a.`id`,
b.`id`,
'1000-01-01 00:00:00' 
FROM
	goods_attr a
	INNER JOIN goods_sku b ON 1 = 1 
WHERE
	a.type = 3 
	AND b.`id` = NEW.`id`;
INSERT INTO goods_attr_text ( `attr_id`, `goods_id`, `attr_value` ) SELECT
a.`id`,
b.`id`,
'' 
FROM
	goods_attr a
	INNER JOIN goods_sku b ON 1 = 1 
WHERE
	a.type = 4 
	AND b.`id` = NEW.`id`;
END;

