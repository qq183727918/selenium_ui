create definer = vevor@`%` trigger attr_varchar_after_update
    after update
    on goods_attr_varchar
    for each row
BEGIN 
IF NEW.attr_id=1 THEN 
UPDATE `view_goods_sku_basic_info` SET `temporary_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=2 THEN 
UPDATE `view_goods_sku_basic_info` SET `product_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=4 THEN 
UPDATE `view_goods_sku_basic_info` SET `images`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=5 THEN 
UPDATE `view_goods_sku_basic_info` SET `voltage`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=6 THEN 
UPDATE `view_goods_sku_basic_info` SET `voltage_plug`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=9 THEN 
UPDATE `view_goods_sku_basic_info` SET `international_brand`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=11 THEN 
UPDATE `view_goods_sku_basic_info` SET `buyer`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=13 THEN 
UPDATE `view_goods_sku_basic_info` SET `reject_before_status`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=14 THEN 
UPDATE `view_goods_sku_basic_info` SET `reject_reason`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=20 THEN 
UPDATE `view_goods_sku_basic_info` SET `invalid_category`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=21 THEN 
UPDATE `view_goods_sku_basic_info` SET `remark`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=23 THEN 
UPDATE `view_goods_sku_basic_info` SET `updated_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=24 THEN 
UPDATE `view_goods_sku_basic_info` SET `created_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=29 THEN 
UPDATE `view_goods_sku_basic_info` SET `item_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=31 THEN 
UPDATE `view_goods_sku_basic_info` SET `sku_code_of_second_sale`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=32 THEN 
UPDATE `view_goods_sku_basic_info` SET `developer_remark`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=33 THEN 
UPDATE `view_goods_sku_basic_info` SET `boss_remark`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=36 THEN 
UPDATE `view_goods_sku_basic_info` SET `user_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=42 THEN 
UPDATE `view_goods_sku_basic_info` SET `sku_code_with_voltage`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=43 THEN 
UPDATE `view_goods_sku_basic_info` SET `sku_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=64 THEN 
UPDATE `view_goods_package_info` SET `created_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=65 THEN 
UPDATE `view_goods_package_info` SET `updated_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=81 THEN 
UPDATE `view_goods_information_basic_info` SET `sku_withplug_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=83 THEN 
UPDATE `view_goods_information_basic_info` SET `sku_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=84 THEN 
UPDATE `view_goods_information_basic_info` SET `images`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=85 THEN 
UPDATE `view_goods_information_basic_info` SET `name_cn`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=86 THEN 
UPDATE `view_goods_information_basic_info` SET `name_en`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=88 THEN 
UPDATE `view_goods_information_basic_info` SET `classification`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=89 THEN 
UPDATE `view_goods_information_basic_info` SET `spu_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=90 THEN 
UPDATE `view_goods_information_basic_info` SET `spu_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=92 THEN 
UPDATE `view_goods_information_basic_info` SET `unpacking_sku_id`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=93 THEN 
UPDATE `view_goods_information_basic_info` SET `sku_kind`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=99 THEN 
UPDATE `view_goods_information_basic_info` SET `brand_cn`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=100 THEN 
UPDATE `view_goods_information_basic_info` SET `brand_en`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=101 THEN 
UPDATE `view_goods_information_basic_info` SET `type_cn`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=102 THEN 
UPDATE `view_goods_information_basic_info` SET `type_en`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=103 THEN 
UPDATE `view_goods_information_basic_info` SET `material_cn`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=104 THEN 
UPDATE `view_goods_information_basic_info` SET `material_en`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=105 THEN 
UPDATE `view_goods_information_basic_info` SET `color`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=109 THEN 
UPDATE `view_goods_information_basic_info` SET `epa_manufacturer_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=110 THEN 
UPDATE `view_goods_information_basic_info` SET `fda_manufacturer_name`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=111 THEN 
UPDATE `view_goods_information_basic_info` SET `epa_manufacturer_address`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=112 THEN 
UPDATE `view_goods_information_basic_info` SET `fda_manufacturer_address`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=116 THEN 
UPDATE `view_goods_information_basic_info` SET `fba_shipping_line`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=117 THEN 
UPDATE `view_goods_information_basic_info` SET `comment`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=118 THEN 
UPDATE `view_goods_information_basic_info` SET `create_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=119 THEN 
UPDATE `view_goods_information_basic_info` SET `update_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=123 THEN 
UPDATE `view_goods_information_size_info` SET `sku_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=132 THEN 
UPDATE `view_goods_information_size_info` SET `create_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=133 THEN 
UPDATE `view_goods_information_size_info` SET `update_by`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=139 THEN 
UPDATE `view_goods_sku_basic_info` SET `main_sku_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=140 THEN 
UPDATE `view_goods_sku_basic_info` SET `sub_sku_code`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=145 THEN 
UPDATE `view_goods_sku_basic_info` SET `supplier`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
IF NEW.attr_id=146 THEN 
UPDATE `view_goods_sku_basic_info` SET `supplier_version`=NEW.attr_value WHERE goods_id=NEW.goods_id; 
END IF; 
END;

