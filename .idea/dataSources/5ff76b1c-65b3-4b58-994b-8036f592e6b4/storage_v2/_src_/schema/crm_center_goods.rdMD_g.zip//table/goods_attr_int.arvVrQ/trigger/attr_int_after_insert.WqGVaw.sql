create definer = vevor@`%` trigger attr_int_after_insert
    after insert
    on goods_attr_int
    for each row
BEGIN 
INSERT INTO `view_goods_sku_basic_info` (goods_id) 
SELECT NEW.goods_id FROM (SELECT 'abc') t WHERE NOT EXISTS (SELECT * FROM `view_goods_sku_basic_info` WHERE goods_id=NEW.goods_id); 
INSERT INTO `view_goods_package_info` (goods_id) 
SELECT NEW.goods_id FROM (SELECT 'abc') t WHERE NOT EXISTS (SELECT * FROM `view_goods_package_info` WHERE goods_id=NEW.goods_id); 
INSERT INTO `view_goods_information_basic_info` (goods_id) 
SELECT NEW.goods_id FROM (SELECT 'abc') t WHERE NOT EXISTS (SELECT * FROM `view_goods_information_basic_info` WHERE goods_id=NEW.goods_id); 
INSERT INTO `view_goods_information_size_info` (goods_id) 
SELECT NEW.goods_id FROM (SELECT 'abc') t WHERE NOT EXISTS (SELECT * FROM `view_goods_information_size_info` WHERE goods_id=NEW.goods_id); 
END;

