create
    definer = vevor@`%` procedure logProcedure()
BEGIN
-- 清空view_goods_operation_log表

-- 查询出product_development_logs的数据
select development_id,logs FROM vevor_evolution.product_development_logs;


-- 将查询出的数据写入view_goods_operation_log中
SELECT * FROM vevor_evolution.view_goods_operation_log;






END;

