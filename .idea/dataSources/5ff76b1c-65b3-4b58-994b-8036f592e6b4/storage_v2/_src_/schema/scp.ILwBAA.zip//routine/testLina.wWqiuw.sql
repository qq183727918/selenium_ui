create
    definer = vevor@`%` procedure testLina()
BEGIN
	DECLARE times int(11) DEFAULT 0;
  WHILE times<90000 DO
	  INSERT INTO `goods_item` (group_id,`platform_id`,`is_active`,`create_time`) VALUES (4,3,0,now());
		SET times=times+1;
	END WHILE;

END;

