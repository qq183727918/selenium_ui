create
    definer = vevor@`%` procedure testzx()
BEGIN
	DECLARE times int(11) DEFAULT 0;
  WHILE times<500000 DO
	  INSERT INTO `goods_item_sku` (`id`,`goods_item_id`,`goods_id`,`platform_sku`,`is_combine_sku`,`item_asin_sn`,`price`,`create_time`,`created_by`)
		VALUES (500001+times,500001+times,500001+times,substring(MD5(RAND()),1,14),0,substring(MD5(RAND()),1,12),100,now(),'zx');
		SET times=times+1;
	END WHILE;

END;

