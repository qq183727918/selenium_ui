create
    definer = vevor@`%` procedure lntest()
BEGIN
  DECLARE times int(11) DEFAULT 0;
  WHILE times<200000 DO
    INSERT INTO `goods_item_sku` (`id`,`goods_item_id`,`goods_id`,`is_combine_sku`,`item_asin_sn`,`price`,`create_time`,`created_by`)
    VALUES (1107028+times,200011+times,200011+times,0,CEILING(RAND()*90000000000000+10000000000000),166.66,now(),'lntest');
    SET times=times+1;
  END WHILE;

END;

