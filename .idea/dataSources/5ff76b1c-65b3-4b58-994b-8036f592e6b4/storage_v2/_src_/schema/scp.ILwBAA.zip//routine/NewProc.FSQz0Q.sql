create
    definer = vevor@`%` procedure NewProc()
BEGIN
	DECLARE times int(11) DEFAULT 0;
  WHILE times<100000 DO
	  INSERT INTO `goods_item` (`id`,`group_id`,`site_id`,`platform_id`,`account_id`,`create_time`,`is_active`) VALUES (100001+times,2,22,2,900,now(),0);
		SET times=times+1;
	END WHILE;

END;

