create
    definer = vevor@`%` procedure testyang()
BEGIN
	DECLARE times int(11) DEFAULT 0;
  WHILE times<100000 DO
	  INSERT INTO `goods_item` (`id`,`platform_id`,`create_time`,`is_active`,group_id,`site_id`,`account_id`) VALUES (1+times,1,now(),0,1,15,367);
		SET times=times+1;
	END WHILE;

END;

