create
    definer = vevor@`%` procedure testshao()
BEGIN
  DECLARE times int(11) DEFAULT 0;
  WHILE times<500000 DO
    INSERT INTO `goods_item_sku` (`id`,`goods_item_id`,`goods_id`,`platform_sku`,`is_combine_sku`,`item_asin_sn`,`price`,`create_time`,`created_by`)
    VALUES (1+times,1+times,1+times,substring(MD5(RAND()),1,14),0,CEILING(RAND()*900000000000+100000000000),100,now(),'ysn');
    SET times=times+1;
  END WHILE;

END;

