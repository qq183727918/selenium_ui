create
    definer = vevor@`%` procedure fillTempData()
BEGIN
  DECLARE times int(11) DEFAULT 0;
	DECLARE gid int(11) DEFAULT 0;
  TRUNCATE TABLE view_goods_sku_basic_info;
	TRUNCATE TABLE goods_attr_varchar;
	TRUNCATE TABLE goods_attr_decimal;
	TRUNCATE TABLE goods_attr_int;
	TRUNCATE TABLE goods_attr_datetime;
	TRUNCATE TABLE goods_attr_text;
	TRUNCATE TABLE basic_sku;
	INSERT INTO `basic_sku` (php_erp_goods_id) VALUES (0);
  WHILE times<1 DO
		set gid=ceil(RAND()*100000000);
	  INSERT INTO `basic_sku` (php_erp_goods_id) 
		SELECT gid FROM basic_sku WHERE php_erp_goods_id<>gid LIMIT 1;
		SET times=times+1;
	END WHILE;
	


END;

