create
    definer = vevor@`%` function getChildList(rootId int) returns varchar(1000)
begin 
	declare result varchar(1000);
	declare tempChild varchar(1000);
	set result = '';
	set tempChild =cast(rootId as char);
	while tempChild is not null do
		set result = concat(result,',',tempChild);
		select group_concat(id) into tempChild from tree where find_in_set(parent_id,tempChild)>0;
	end while;
	return result;
end;

